var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
console.log("hi");
let request = new XMLHttpRequest();
request.open("GET", "https://www.googleapis.com/calendar/v3/calendars/tremendoustuple@gmail.com/events?key=AIzaSyCIBb7UZXl7Lphhsa32ahbzoetRaYjmqZc");
request.send();
request.onload = () => {
  console.log(request);
}