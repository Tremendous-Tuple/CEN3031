# CEN3031
The best team in CEN 3031! 

# Project
Our final project is to create a dynamic website for the Society of Software Developers.

# Team Members
Derek Perdomo   - Project Manager / Backend Developer
Caijun Qin      - Backend Developer
Robert Obendorf - Scrum Master / Frontend Developer

# Contact Us
If you need to contact any of the teammates, please send an email to [tremendoustuple@gmail.com](tremendoustuple@gmail.com)

# As always... GO GATORS!!!!
